var bio = {
    "name": "Laura Wilson-Carter",
    "role": "Front End Developer",
    "contacts": {
        "mobile": "972-977-8981",
        "email": "laraca2323@verizon.net",
        "github": "laraca2323",        "twitter": "@laraca2323",
        "location": "Plano, TX",
    },
    "welcomeMessage": "Welcome to my online resume!",
    "skills": ["HTML", " CSS", " Python ", " Javascript ", " Dev Ops ", " Customer Service ", " Content Delivery "],
    "biopic": "images/Laura.JPG",
   };

   bio.display = function () {

     var formattedName = HTMLheaderName.replace("%data%", bio.name);

     var formattedRole = HTMLheaderRole.replace("%data%", bio.role);

     var formattedMobile = HTMLmobile.replace("%data%", bio.contacts.mobile);

     var formattedEmail = HTMLemail.replace("%data%", bio.contacts.email);

     var formattedGithub = HTMLgithub.replace("%data%", bio.contacts.github);

     var formattedTwitter = HTMLtwitter.replace("%data%", bio.contacts.twitter);

     var formattedLocation = HTMLlocation.replace("%data%", bio.contacts.location);

     var formattedWelcomeMessage = HTMLwelcomeMsg.replace("%data%", bio.welcomeMessage);

     var formattedPicture = HTMLbioPic.replace("%data%", bio.biopic);


     $("#header").prepend(formattedRole);
     $("#header").prepend(formattedName);
     $("#topContacts, #footerContacts").append(formattedLocation);
     $("#topContacts, #footerContacts").append(formattedMobile);
     $("#topContacts, #footerContacts").append(formattedEmail);
     $("#topContacts, #footerContacts").append(formattedTwitter);
     $("#topContacts, #footerContacts").append(formattedGithub);
     $("#header").prepend(formattedPicture);
     $("#header").append(formattedWelcomeMessage);
     $("#main").append(internationalizeButton);

     //var to display skills in header of the resume and uses variables associated to files ref above
     $("#header").append(HTMLskillsStart);
       for (var skill = 0; skill < bio.skills.length; skill++) {

         var formattedSkill = HTMLskills.replace("%data%", bio.skills[skill]);
         $("#skills:last").append(formattedSkill);
     }
 };
   bio.display();


   var education = {
         "schools" : [
           {
           "name": "Richland College",
           "degree": "Art History",
           "majors": ["Art History"],
           "location": "Dallas, TX",
                 "dates": "1984-1988",
           "url": "http:///www.richlandcollege.edu/"
             }
        ],

       "onlineCourses": [
         {
           "title": "Intro to Programming",
           "school": "Udacity",
           "dates": "2017",
           "url": "https://www.udacity.com/course/intro-to-programming-nanodegree--nd000"
         }
       ]
       }; //


  education.display=function() {
    education.schools.forEach(function(school) {
        $("#education").append(HTMLschoolStart);


        var formattedName = HTMLschoolName.replace("%data%", school.name);
        var formattedDegree = HTMLschoolDegree.replace("%data%", school.degree);
        var formattedEducationTitle = formattedName + formattedDegree;
        $(".education-entry:last").append(formattedEducationTitle);


        var formattedDates = HTMLschoolDates.replace("%data%", school.dates);
        $(".education-entry:last").append(formattedDates);


        var formattedLocation = HTMLschoolLocation.replace("%data%", school.location);
        $(".education-entry:last").append(formattedLocation);


        var formattedMajor = HTMLschoolMajor.replace("%data%", school.majors);
        $(".education-entry:last").append(formattedMajor);


        var formattedUrl = HTMLonlineURL.replace("%data%", school.url);
        $(".education-entry:last").append(formattedUrl);
      });


        $("#education").append(HTMLonlineClasses);


      education.onlineCourses.forEach(function(onlineCourse) {
        $("#education").append(HTMLschoolStart);
        var OnlineCourseName = HTMLonlineTitle.replace("%data%", onlineCourse.title);
        var OnlineCourseSchool = HTMLonlineSchool.replace("%data%", onlineCourse.school);
        var OnlineCourseTitle = OnlineCourseName + OnlineCourseSchool;
        $(".education-entry:last").append(OnlineCourseTitle);


        var OnlineCourseDates = HTMLonlineDates.replace("%data%", onlineCourse.dates);
        $(".education-entry:last").append(OnlineCourseDates);


        var OnlineCourseUrl = HTMLonlineURL.replace("%data%", onlineCourse.url);
        $(".education-entry:last").append(OnlineCourseUrl);
    });
  };


  education.display();








    var work = {
      "jobs": [
        {
          "title": "Senior Training Manager",
          "employer": "AT&T University",
          "dates": "1997 - present",
          "location": "Farmers Branch, TX",
          "description": "Support the training needs for Credit and Activations by training representatives to perform analyst reviews for retail store agents to help complete credit applications. Supported the training needs for AT&T Digital Life Monitoring Center agents who provides alarm monitoring, fire, police, and medical dispatch services for AT&T Digital Life customers."
        },
        {
          "title": "Certified Gemologist",
          "employer": "Ocean Jewels",
          "dates": "1990 - 1996",
          "location": "Dallas, TX",
          "description": "Pearl Stringer, Jewelery repairs, Diamond Certifier"
        },
        {
          "title": "Communication Specialist",
          "employer": "Voice Retreival",
          "dates": "1989 - 1990",
          "location": "Farmers Branch, TX",
          "description": "Communication specialist, router, paging system"
        }
      ]
    };


    work.display=function() {
      work.jobs.forEach(function(job) {
        // create new div for workExperience
        $("#workExperience").append(HTMLworkStart);
        // concat employer and job position
        var formattedEmployer = HTMLworkEmployer.replace ("%data%", job.employer);
        var formattedPosition = HTMLworkTitle.replace("%data%", job.title);
        var formattedEmployerTitle = formattedEmployer + formattedPosition;
        $(".work-entry:last").append(formattedEmployerTitle);


        var formattedDates = HTMLworkDates.replace ("%data%", job.dates);
        $(".work-entry:last").append(formattedDates);


        var formattedLocation = HTMLworkLocation.replace ("%data%", job.location);
        $(".work-entry:last").append(formattedLocation);


        var formattedDescription = HTMLworkDescription.replace ("%data%", job.description);
        $(".work-entry:last").append(formattedDescription);
      });
    };


    work.display();


  var projects = {
      "projects": [
        {
          "title": "CPXX Projects",
          "description": "Work Stoppage",
          "dates": "Oct. 2017",
          "images": ["images/ATT.jpg "]
        },
        {
          "title": "Bridal Necklace",
          "description": "Wedding Necklace!",
          "dates": "June 1993",
          "images": ["images/bridal-jewelry.jpg "]
        },
        {
          "title": "Data Communication",
          "description": "Router Services",
          "dates": "September 1990",
          "images": ["images/Data Coding.jpg"]
        }
      ]
    };


  projects.display=function() {


        projects.projects.forEach(function(project) {
          // create new div for projectExperience
          $("#projects").append(HTMLprojectStart);


          var formattedProjectTitle = HTMLprojectTitle.replace ("%data%", project.title);
          $(".project-entry:last").append(formattedProjectTitle);


          var formattedProjectDuration = HTMLprojectDates.replace ("%data%", project.dates);
          $(".project-entry:last").append(formattedProjectDuration);


          var formattedProjectDescription = HTMLprojectDescription.replace ("%data%", project.description);
          $(".project-entry:last").append(formattedProjectDescription);


          project.images.forEach(function(image) {
          var formattedProjectImage = HTMLprojectImage.replace ("%data%", project.images);
          $(".project-entry:last").append(formattedProjectImage);
      });
    });
    };


  projects.display();


  $("#mapDiv").append(googleMap);
